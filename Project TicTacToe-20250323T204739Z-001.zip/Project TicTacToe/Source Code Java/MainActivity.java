package com.example.mytictactoe;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button btn0,btn1,btn2,btn3,btn4,btn5,btn6,btn7,btn8;
    TextView headerText;

    int PLAYER_0 = 0;
    int PLAYER_1 = 1;

    //this player will go first
    int activePlayer = PLAYER_0;

    //for checking if the box is already filled or not
    int []filledPosition = {-1,-1,-1,-1,-1,-1,-1,-1,-1};

    //after winning to finish the game
    boolean isGameActive = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        headerText = findViewById(R.id.header_text);
        headerText.setText("O's Turn");
        btn0=findViewById(R.id.btn0);
        btn1=findViewById(R.id.btn1);
        btn2=findViewById(R.id.btn2);
        btn3=findViewById(R.id.btn3);
        btn4=findViewById(R.id.btn4);
        btn5=findViewById(R.id.btn5);
        btn6=findViewById(R.id.btn6);
        btn7=findViewById(R.id.btn7);
        btn8=findViewById(R.id.btn8);

        btn0.setOnClickListener(this);
        btn1.setOnClickListener(this);
        btn2.setOnClickListener(this);
        btn3.setOnClickListener(this);
        btn4.setOnClickListener(this);
        btn5.setOnClickListener(this);
        btn6.setOnClickListener(this);
        btn7.setOnClickListener(this);
        btn8.setOnClickListener(this);

    }

    @SuppressLint("ResourceAsColor")
    @Override
    public void onClick(View v) {

        if (!isGameActive){
            return;
        }
        //logic for button press
        Button clickedBtn = findViewById(v.getId());
        int clickedTag = Integer.parseInt(v.getTag().toString());

        if (filledPosition[clickedTag] != -1){
            return;
        }

        filledPosition[clickedTag] = activePlayer;

        if (activePlayer == PLAYER_0){
            clickedBtn.setText("O");
            clickedBtn.setBackground(getDrawable(android.R.color.holo_green_light));
            activePlayer = PLAYER_1;
            headerText.setText("X's turn");
        }
        else {
            clickedBtn.setText("X");
            clickedBtn.setBackground(getDrawable(android.R.color.holo_orange_light));
            activePlayer = PLAYER_0;
            headerText.setText("O's turn");
        }
        checkForWin();
    }

    private void checkForWin(){
        //checking wining positions
        int [][] winningPos = {{0,1,2},{3,4,5},{6,7,8},{0,3,6},{1,4,7},{2,5,8},{0,4,8},{2,4,6}};

        for (int i = 0; i<8; i++) {
            int val_0 = winningPos[i][0];
            int val_1 = winningPos[i][1];
            int val_2 = winningPos[i][2];

            if (filledPosition[val_0] == filledPosition[val_1] && filledPosition[val_1] == filledPosition[val_2]) {
                if (filledPosition[val_0] != -1) {
                    //winner declare
                    isGameActive = false; //if winner is declared then the game should stop

                    if (filledPosition[val_0] == PLAYER_0) {
                        showDialog("O is Winner");
                    }
                    else {
                        showDialog("X is Winner");
                    }
                }
            }
        }
        int count = 0;
        for (int i1 = 0; i1 < 8; i1++){
            if (filledPosition[i1] != -1){
                count += 1;
            }
        }
        if (count == 8){
            showDialog("Match Draw");
        }

    }

    //showing dialog to restart the game
    private void showDialog(String winnerText){
        new AlertDialog.Builder(this)
                .setTitle(winnerText)
                .setPositiveButton("Restart Game", new DialogInterface.OnClickListener() {//adding restart button
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        restartGame();
                    }
                })
                .show();
    }
    //this happens after clicking that Restart game button
    private void restartGame(){

        activePlayer = PLAYER_0; //setting player_0 as active player
        headerText.setText("O's Turn");
        filledPosition = new int[] {-1,-1,-1,-1,-1,-1,-1,-1,-1}; //setting all the fields as blank

        //setting all the buttons as empty
        btn0.setText("");
        btn1.setText("");
        btn2.setText("");
        btn3.setText("");
        btn4.setText("");
        btn5.setText("");
        btn6.setText("");
        btn7.setText("");
        btn8.setText("");

        //setting the color of the bg as default for all btns
        btn0.setBackground(getDrawable(R.color.teal_200));
        btn1.setBackground(getDrawable(R.color.teal_200));
        btn2.setBackground(getDrawable(R.color.teal_200));
        btn3.setBackground(getDrawable(R.color.teal_200));
        btn4.setBackground(getDrawable(R.color.teal_200));
        btn5.setBackground(getDrawable(R.color.teal_200));
        btn6.setBackground(getDrawable(R.color.teal_200));
        btn7.setBackground(getDrawable(R.color.teal_200));
        btn8.setBackground(getDrawable(R.color.teal_200));

        isGameActive = true; //setting the game as active again

    }

}